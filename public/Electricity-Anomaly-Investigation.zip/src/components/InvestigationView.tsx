import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  SearchCode, 
  CheckCircle2, 
  Printer, 
  Sparkles, 
  Cpu, 
  Layers, 
  History, 
  HelpCircle, 
  Wrench,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { FullInvestigationReport, AnomalyCase } from '../types';

interface InvestigationViewProps {
  selectedMeterId?: string;
  selectedDate?: string;
  anomalyCases: AnomalyCase[];
  onSelectAnotherCase: (meter_id: string, date: string) => void;
}

export const InvestigationView: React.FC<InvestigationViewProps> = ({
  selectedMeterId,
  selectedDate,
  anomalyCases,
  onSelectAnotherCase,
}) => {
  const [currentMeter, setCurrentMeter] = useState<string>(selectedMeterId || anomalyCases[0]?.meter_id || 'MT_007');
  const [currentDate, setCurrentDate] = useState<string>(selectedDate || anomalyCases[0]?.date || '2025-04-12');
  const [report, setReport] = useState<FullInvestigationReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Sync props when user clicked from Anomaly table
  useEffect(() => {
    if (selectedMeterId && selectedDate) {
      setCurrentMeter(selectedMeterId);
      setCurrentDate(selectedDate);
    }
  }, [selectedMeterId, selectedDate]);

  // Fetch report whenever meter or date changes
  useEffect(() => {
    async function fetchInvestigation() {
      if (!currentMeter || !currentDate) return;
      setLoading(true);
      setError(null);
      try {
        const res = await fetch('/api/investigate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ meter_id: currentMeter, date: currentDate }),
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || 'Failed to generate investigation dossier');
        }
        const data = await res.json();
        setReport(data.report);
      } catch (err: any) {
        console.error('Investigation fetch error:', err);
        setError(err.message || 'Error executing investigation');
      } finally {
        setLoading(false);
      }
    }
    fetchInvestigation();
  }, [currentMeter, currentDate]);

  const timelineSteps = [
    { title: 'Anomaly Detected', desc: 'Isolation Forest flagged load outlier' },
    { title: 'Historical Pattern Checked', desc: '14-day & 365-day baselines retrieved' },
    { title: 'Context Analyzed', desc: 'Zone, consumer type & volatility audited' },
    { title: 'Possible Causes Identified', desc: 'Hardware, operational & loss hypotheses' },
    { title: 'Priority Assigned', desc: 'Action triage rank calibrated' },
    { title: 'Verification Recommended', desc: '4-step field technical inspection protocol' },
  ];

  return (
    <div className="space-y-6">
      {/* Case Selector Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <SearchCode className="w-4 h-4 text-sky-400" />
            Agentic AI Forensic Investigation Dossier
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated contextual reasoning and multi-step hypothesis formulation
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label htmlFor="anomaly-case-select" className="text-xs text-slate-400 font-medium">Select Case Dossier:</label>
          <select
            id="anomaly-case-select"
            value={`${currentMeter}_${currentDate}`}
            onChange={(e) => {
              const [m, d] = e.target.value.split('_');
              setCurrentMeter(m);
              setCurrentDate(d);
              onSelectAnotherCase(m, d);
            }}
            className="bg-slate-950 text-sky-400 text-xs font-mono font-bold px-3 py-1.5 rounded-lg border border-slate-700 outline-none focus:border-sky-500 max-w-xs"
          >
            {anomalyCases.map((a, i) => (
              <option key={i} value={`${a.meter_id}_${a.date}`}>
                [{a.priority}] {a.meter_id} &bull; {a.date} ({a.percentage_change > 0 ? '+' : ''}{a.percentage_change.toFixed(1)}%)
              </option>
            ))}
          </select>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 transition"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Dossier
          </button>
        </div>
      </div>

      {/* Visual Investigation Timeline */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
          <Layers className="w-3.5 h-3.5 text-sky-400" />
          Agentic Investigation Workflow Execution Sequence
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {timelineSteps.map((step, idx) => (
            <div
              key={idx}
              className="bg-slate-950/80 border border-slate-800 rounded-lg p-3 relative flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center font-mono text-[10px] font-bold">
                  {idx + 1}
                </span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-slate-200 leading-tight">{step.title}</div>
                <div className="text-[10px] text-slate-400 mt-1 leading-normal">{step.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-16 text-center shadow-xl">
          <div className="inline-block animate-spin w-8 h-8 border-4 border-sky-500 border-t-transparent rounded-full mb-3" />
          <div className="text-sm font-semibold text-white">Synthesizing Forensic Reasoning...</div>
          <div className="text-xs text-slate-400 mt-1">Executing agent tools & generating contextual investigation report</div>
        </div>
      ) : error ? (
        <div className="bg-rose-950/20 border border-rose-500/30 rounded-xl p-8 text-center text-rose-300">
          <AlertTriangle className="w-8 h-8 text-rose-400 mx-auto mb-2" />
          <div className="font-bold text-sm">Investigation Error</div>
          <p className="text-xs text-rose-200 mt-1">{error}</p>
        </div>
      ) : report ? (
        <div className="space-y-6">
          {/* Dossier Header & Parameters Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 mb-5 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                    Case Dossier: {report.meter_id}
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium border ${
                      report.reasoning_source === 'GEMINI_AI'
                        ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                        : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                    }`}
                  >
                    {report.reasoning_source === 'GEMINI_AI' ? (
                      <>
                        <Sparkles className="w-3 h-3" /> Gemini 3.8 Flash Engine
                      </>
                    ) : (
                      <>
                        <Cpu className="w-3 h-3" /> Deterministic Expert System
                      </>
                    )}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-white mt-1">
                  Meter {report.meter_id} &bull; {report.consumer_type} ({report.location})
                </h3>
              </div>

              <div className="flex items-center gap-4">
                <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-right">
                  <div className="text-[10px] uppercase text-slate-400">Incident Date</div>
                  <div className="font-mono font-bold text-sky-400">{report.date}</div>
                </div>

                <div
                  className={`px-4 py-2 rounded-lg border text-center ${
                    report.investigation_priority === 'HIGH'
                      ? 'bg-rose-500/15 border-rose-500/30 text-rose-300'
                      : report.investigation_priority === 'MEDIUM'
                      ? 'bg-amber-500/15 border-amber-500/30 text-amber-300'
                      : 'bg-sky-500/15 border-sky-500/30 text-sky-300'
                  }`}
                >
                  <div className="text-[10px] uppercase tracking-wider font-bold">Investigation Priority</div>
                  <div className="text-base font-mono font-bold">{report.investigation_priority}</div>
                </div>
              </div>
            </div>

            {/* Consumption Parameters Matrix */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-[10px] uppercase font-medium text-slate-400">Recorded Load</div>
                <div className="text-base font-mono font-bold text-white mt-1">
                  {report.consumption_analysis.recorded_kwh.toFixed(2)} <span className="text-xs text-slate-400">kWh</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Incident day total</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-[10px] uppercase font-medium text-slate-400">Historical Baseline</div>
                <div className="text-base font-mono font-bold text-slate-300 mt-1">
                  {report.consumption_analysis.baseline_kwh.toFixed(2)} <span className="text-xs text-slate-400">kWh</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Expanding mean</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-[10px] uppercase font-medium text-slate-400">Percentage Deviation</div>
                <div
                  className={`text-base font-mono font-bold mt-1 ${
                    report.consumption_analysis.percentage_change < 0 ? 'text-rose-400' : 'text-amber-400'
                  }`}
                >
                  {report.consumption_analysis.percentage_change > 0 ? '+' : ''}
                  {report.consumption_analysis.percentage_change.toFixed(1)}%
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Relative to baseline</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-[10px] uppercase font-medium text-slate-400">Anomaly Score</div>
                <div className="text-base font-mono font-bold text-purple-400 mt-1">
                  {report.consumption_analysis.anomaly_score.toFixed(4)}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Isolation Forest metric</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-[10px] uppercase font-medium text-slate-400">Standardized Z-Score</div>
                <div className="text-base font-mono font-bold text-cyan-400 mt-1">
                  {report.consumption_analysis.z_score}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">&sigma; = {report.consumption_analysis.historical_std.toFixed(1)}</div>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="text-[10px] uppercase font-medium text-slate-400">Consecutive Outliers</div>
                <div className="text-base font-mono font-bold text-amber-400 mt-1">
                  {report.consumption_analysis.consecutive_abnormal_days}{' '}
                  <span className="text-xs text-slate-400">days</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">Persistence window</div>
              </div>
            </div>
          </div>

          {/* Section 1: Observed Pattern */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-3 pb-2 border-b border-slate-800">
              <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-sky-500/15 text-sky-400">01</span>
              <h4 className="font-bold text-white text-sm">Observed Pattern</h4>
            </div>
            <div className="bg-gradient-to-r from-sky-950/40 to-slate-950 border-l-4 border-sky-400 p-4 rounded-r-lg text-slate-200 leading-relaxed text-sm">
              {report.observed_pattern}
            </div>
          </div>

          {/* Section 2: Historical Comparison & Contextual Interpretation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
              <div className="flex items-center gap-3 mb-3 pb-2 border-b border-slate-800">
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-sky-500/15 text-sky-400">02</span>
                <h4 className="font-bold text-white text-sm">Historical Baseline Comparison</h4>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {report.historical_comparison}
              </p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
              <div className="flex items-center gap-3 mb-3 pb-2 border-b border-slate-800">
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-sky-500/15 text-sky-400">03</span>
                <h4 className="font-bold text-white text-sm">Contextual Interpretation ({report.consumer_type})</h4>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {report.contextual_interpretation}
              </p>
            </div>
          </div>

          {/* Section 3: Surrounding 14-Day Trajectory */}
          {report.history_window && report.history_window.length > 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
              <div className="flex items-center gap-3 mb-3 pb-2 border-b border-slate-800">
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-sky-500/15 text-sky-400">04</span>
                <h4 className="font-bold text-white text-sm">Surrounding 14-Day Load Trajectory</h4>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <th className="p-2.5">Date</th>
                      <th className="p-2.5">Daily Consumption</th>
                      <th className="p-2.5">Historical Baseline</th>
                      <th className="p-2.5">Relative Deviation</th>
                      <th className="p-2.5">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {report.history_window.map((h, i) => (
                      <tr key={i} className={h.is_target ? 'bg-rose-950/20 font-semibold' : 'hover:bg-slate-800/30'}>
                        <td className="p-2.5 font-mono">
                          {h.date}
                          {h.is_target && (
                            <span className="ml-2 px-1.5 py-0.5 rounded text-[10px] bg-rose-500 text-white font-sans font-bold">
                              INCIDENT TARGET
                            </span>
                          )}
                        </td>
                        <td className="p-2.5 font-mono font-bold text-white">{h.consumption.toFixed(2)} kWh</td>
                        <td className="p-2.5 font-mono text-slate-400">{h.historical_average.toFixed(2)} kWh</td>
                        <td className="p-2.5 font-mono">
                          <span className={h.percentage_change < 0 ? 'text-rose-400' : 'text-amber-400'}>
                            {h.percentage_change > 0 ? '+' : ''}
                            {h.percentage_change.toFixed(1)}%
                          </span>
                        </td>
                        <td className="p-2.5">
                          {h.is_target ? (
                            <span className="text-rose-400 font-medium">Flagged Outlier</span>
                          ) : (
                            <span className="text-slate-400">Normal Range</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Section 4: Possible Causes & Differential Hypotheses */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-3 pb-2 border-b border-slate-800">
              <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-sky-500/15 text-sky-400">05</span>
              <h4 className="font-bold text-white text-sm">Plausible Causes & Engineering Hypotheses</h4>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              The Agentic AI evaluated telemetry behavior against utility distribution failure archetypes:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {report.possible_causes.map((cause, i) => (
                <div key={i} className="bg-slate-950 border border-slate-800 rounded-lg p-4">
                  <span className="text-[10px] font-mono font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {cause.category.replace('_', ' ')}
                  </span>
                  <h5 className="font-semibold text-white text-sm mt-2">{cause.title}</h5>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{cause.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Section 5: Recommended Verification Action */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-3 pb-2 border-b border-slate-800">
              <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-sky-500/15 text-sky-400">06</span>
              <h4 className="font-bold text-white text-sm">Recommended Sequential Verification Actions</h4>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Recommended standardized protocol for utility investigation engineers and field crews:
            </p>
            <div className="space-y-3">
              {report.recommended_actions.map((act) => (
                <div
                  key={act.step}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-4 flex items-start gap-4"
                >
                  <div className="px-2.5 py-1 rounded bg-sky-600 text-white font-mono text-xs font-bold shrink-0">
                    Step {act.step}
                  </div>
                  <div>
                    <h5 className="font-semibold text-white text-sm">{act.title}</h5>
                    <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{act.action}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 6: System Limitation Disclaimer */}
          <div className="bg-rose-950/20 border border-rose-500/30 rounded-xl p-5 text-rose-200 text-xs flex items-center gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <strong className="text-rose-300">Mandatory System Limitation:</strong> {report.system_limitation}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
