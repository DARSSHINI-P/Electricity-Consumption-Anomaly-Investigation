import React, { useState, useEffect, useMemo } from 'react';
import { Gauge, Zap, Calendar, AlertOctagon, TrendingDown, TrendingUp, CheckCircle, SearchCode } from 'lucide-react';
import { MeterSummary } from '../types';

interface MeterDetailResponse {
  stats: MeterSummary;
  records: Array<{
    meter_id: string;
    date: string;
    consumption: number;
    historical_average: number;
    rolling_average: number;
    percentage_change: number;
    is_anomaly: boolean;
    priority: string;
    anomaly_score: number;
  }>;
  anomalous_dates: string[];
}

interface MeterAnalysisViewProps {
  initialMeterId?: string;
  onInvestigate: (meter_id: string, date: string) => void;
}

export const MeterAnalysisView: React.FC<MeterAnalysisViewProps> = ({
  initialMeterId = 'MT_001',
  onInvestigate,
}) => {
  const [metersList, setMetersList] = useState<MeterSummary[]>([]);
  const [selectedMeterId, setSelectedMeterId] = useState<string>(initialMeterId);
  const [meterDetail, setMeterDetail] = useState<MeterDetailResponse | null>(null);
  const [loading, setLoading] = useState(false);

  // Load meter directory
  useEffect(() => {
    async function loadMeters() {
      try {
        const res = await fetch('/api/meters');
        if (res.ok) {
          const data = await res.json();
          setMetersList(data.meters || []);
        }
      } catch (err) {
        console.error('Error loading meters:', err);
      }
    }
    loadMeters();
  }, []);

  // Load selected meter telemetry
  useEffect(() => {
    async function loadDetail() {
      if (!selectedMeterId) return;
      setLoading(true);
      try {
        const res = await fetch(`/api/meter/${selectedMeterId}`);
        if (res.ok) {
          const data = await res.json();
          setMeterDetail(data);
        }
      } catch (err) {
        console.error('Error loading meter detail:', err);
      } finally {
        setLoading(false);
      }
    }
    loadDetail();
  }, [selectedMeterId]);

  // SVG Chart calculation for 365 days
  const chartSvg = useMemo(() => {
    if (!meterDetail || !meterDetail.records || meterDetail.records.length === 0) return null;

    const width = 1000;
    const height = 300;
    const padding = { top: 20, right: 30, bottom: 40, left: 60 };

    const records = meterDetail.records;
    const maxVal = Math.max(...records.map((r) => r.consumption), ...records.map((r) => r.historical_average), 100) * 1.1;
    const minVal = 0;

    const points = records.map((r, i) => {
      const x = padding.left + (i / (records.length - 1)) * (width - padding.left - padding.right);
      const y = height - padding.bottom - ((r.consumption - minVal) / (maxVal - minVal)) * (height - padding.top - padding.bottom);
      const yBase = height - padding.bottom - ((r.historical_average - minVal) / (maxVal - minVal)) * (height - padding.top - padding.bottom);
      return { x, y, yBase, record: r };
    });

    const consumptionPath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
    const baselinePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.yBase.toFixed(1)}`).join(' ');

    const anomalyPoints = points.filter((p) => p.record.is_anomaly);

    return {
      width,
      height,
      padding,
      maxVal,
      consumptionPath,
      baselinePath,
      anomalyPoints,
      totalPoints: points.length,
    };
  }, [meterDetail]);

  const stats = meterDetail?.stats;

  return (
    <div className="space-y-6">
      {/* Meter Header & Selector Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Gauge className="w-4 h-4 text-sky-400" />
            Smart Meter Telemetry Profile & Longitudinal Analysis
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Select an individual utility meter to inspect baseline load curves and anomaly occurrences
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label htmlFor="meter-selector" className="text-xs text-slate-400 font-medium">Select Channel:</label>
          <select
            id="meter-selector"
            value={selectedMeterId}
            onChange={(e) => setSelectedMeterId(e.target.value)}
            className="bg-slate-950 text-sky-400 text-xs font-mono font-bold px-3 py-1.5 rounded-lg border border-slate-700 outline-none focus:border-sky-500"
          >
            {metersList.map((m) => (
              <option key={m.meter_id} value={m.meter_id}>
                {m.meter_id} &bull; {m.consumer_type} ({m.location})
              </option>
            ))}
          </select>
        </div>
      </div>

      {stats && (
        <>
          {/* Specific Meter KPI Profile Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Meter ID</div>
              <div className="text-lg font-mono font-bold text-sky-400 mt-1">{stats.meter_id}</div>
              <div className="text-[10px] text-slate-400 mt-0.5">{stats.consumer_type}</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Location Zone</div>
              <div className="text-sm font-semibold text-white mt-1 truncate">{stats.location}</div>
              <div className="text-[10px] text-slate-400 mt-0.5">Chennai Grid</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Daily Mean Load</div>
              <div className="text-lg font-mono font-bold text-white mt-1">
                {stats.mean_consumption.toFixed(1)} <span className="text-[10px] font-normal text-slate-400">kWh</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">&sigma; = {stats.std_consumption.toFixed(1)}</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Min Reading</div>
              <div className="text-lg font-mono font-bold text-emerald-400 mt-1">
                {stats.min_consumption.toFixed(1)} <span className="text-[10px] font-normal text-slate-400">kWh</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Annual low</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Max Reading</div>
              <div className="text-lg font-mono font-bold text-rose-400 mt-1">
                {stats.max_consumption.toFixed(1)} <span className="text-[10px] font-normal text-slate-400">kWh</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Peak day load</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
              <div className="text-[10px] text-slate-400 uppercase font-bold">Total Energy</div>
              <div className="text-lg font-mono font-bold text-purple-400 mt-1">
                {Math.round(stats.total_kwh / 1000).toLocaleString()}{' '}
                <span className="text-[10px] font-normal text-slate-400">MWh</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">365-day total</div>
            </div>

            <div className={`p-4 rounded-xl shadow-lg border ${
              stats.anomalies_count > 0 
                ? 'bg-rose-950/20 border-rose-500/30' 
                : 'bg-emerald-950/20 border-emerald-500/30'
            }`}>
              <div className="text-[10px] text-slate-400 uppercase font-bold">Anomalies</div>
              <div className={`text-lg font-mono font-bold mt-1 ${stats.anomalies_count > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {stats.anomalies_count}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Outlier points</div>
            </div>
          </div>

          {/* 365-Day Interactive Telemetry Line Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-sky-400" />
                  Annual Load Trajectory & Isolation Forest Anomaly Highlighting
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Daily consumption (blue) vs Expanding Baseline (purple). Highlighted red markers denote flagged anomalies.
                </p>
              </div>

              <div className="flex items-center gap-4 text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-sky-400 inline-block" /> Daily Load (kWh)
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-purple-400 border-dashed inline-block" /> Historical Mean
                </span>
                <span className="flex items-center gap-1.5 text-rose-400 font-medium">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 border border-white inline-block" /> Flagged Anomaly (Click to Investigate)
                </span>
              </div>
            </div>

            {/* SVG Chart */}
            <div className="w-full h-72 bg-slate-950/80 rounded-lg p-2 border border-slate-800/80 relative flex items-center justify-center overflow-hidden">
              {loading ? (
                <div className="text-xs text-slate-400">Loading meter series...</div>
              ) : chartSvg ? (
                <svg
                  viewBox={`0 0 ${chartSvg.width} ${chartSvg.height}`}
                  className="w-full h-full overflow-visible"
                  preserveAspectRatio="none"
                >
                  {/* Grid lines */}
                  {[0, 0.25, 0.5, 0.75, 1].map((pct, i) => {
                    const y =
                      chartSvg.padding.top +
                      pct * (chartSvg.height - chartSvg.padding.top - chartSvg.padding.bottom);
                    return (
                      <line
                        key={i}
                        x1={chartSvg.padding.left}
                        y1={y}
                        x2={chartSvg.width - chartSvg.padding.right}
                        y2={y}
                        stroke="#1e293b"
                        strokeDasharray="4 4"
                        strokeWidth="0.8"
                      />
                    );
                  })}

                  {/* Baseline path */}
                  <path
                    d={chartSvg.baselinePath}
                    fill="none"
                    stroke="#c084fc"
                    strokeWidth="1.8"
                    strokeDasharray="5 4"
                  />

                  {/* Consumption path */}
                  <path
                    d={chartSvg.consumptionPath}
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="2"
                  />

                  {/* Anomaly Points */}
                  {chartSvg.anomalyPoints.map((pt, i) => (
                    <g
                      key={i}
                      className="cursor-pointer group"
                      onClick={() => onInvestigate(pt.record.meter_id, pt.record.date)}
                    >
                      <circle
                        cx={pt.x}
                        cy={pt.y}
                        r="5.5"
                        fill="#f43f5e"
                        stroke="#ffffff"
                        strokeWidth="1.8"
                      />
                      <title>{`Anomaly on ${pt.record.date}: ${pt.record.consumption} kWh (${pt.record.percentage_change}% change) - Click to Investigate`}</title>
                    </g>
                  ))}
                </svg>
              ) : (
                <div className="text-xs text-slate-400">No telemetry records found.</div>
              )}
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-800">
              <span>2025-01-01</span>
              <span>Mid-Year (June 2025)</span>
              <span>2025-12-31</span>
            </div>
          </div>

          {/* Meter's Flagged Anomalies Sub-Table */}
          {stats.anomalies_count > 0 && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                <AlertOctagon className="w-4 h-4 text-rose-400" />
                Detected Anomaly Incidents for Meter {stats.meter_id}
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <th className="p-2.5">Date</th>
                      <th className="p-2.5">Recorded Load</th>
                      <th className="p-2.5">Historical Baseline</th>
                      <th className="p-2.5">Deviation (%)</th>
                      <th className="p-2.5">Anomaly Score</th>
                      <th className="p-2.5">Priority</th>
                      <th className="p-2.5 text-right">Forensic Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {meterDetail?.records
                      .filter((r) => r.is_anomaly)
                      .map((r, i) => (
                        <tr key={i} className="hover:bg-slate-800/40">
                          <td className="p-2.5 font-mono">{r.date}</td>
                          <td className="p-2.5 font-mono font-bold text-white">{r.consumption.toFixed(2)} kWh</td>
                          <td className="p-2.5 font-mono text-slate-400">{r.historical_average.toFixed(2)} kWh</td>
                          <td className="p-2.5 font-mono">
                            <span
                              className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                                r.percentage_change < 0
                                  ? 'bg-rose-500/15 text-rose-300'
                                  : 'bg-amber-500/15 text-amber-300'
                              }`}
                            >
                              {r.percentage_change > 0 ? '+' : ''}
                              {r.percentage_change.toFixed(1)}%
                            </span>
                          </td>
                          <td className="p-2.5 font-mono text-purple-400">{r.anomaly_score.toFixed(4)}</td>
                          <td className="p-2.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                                r.priority === 'HIGH'
                                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                  : r.priority === 'MEDIUM'
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                  : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                              }`}
                            >
                              {r.priority}
                            </span>
                          </td>
                          <td className="p-2.5 text-right">
                            <button
                              onClick={() => onInvestigate(r.meter_id, r.date)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-sky-500/15 hover:bg-sky-500 text-sky-400 hover:text-slate-900 border border-sky-500/30 text-xs font-medium transition"
                            >
                              Launch AI Investigation &rarr;
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
