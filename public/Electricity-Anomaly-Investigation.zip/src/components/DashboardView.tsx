import React from 'react';
import { 
  Activity, 
  Database, 
  AlertOctagon, 
  ShieldAlert, 
  TrendingUp, 
  MapPin, 
  Users, 
  PieChart, 
  Calendar,
  ArrowRight
} from 'lucide-react';
import { KpiSummary, ChartDataSets, AnomalyCase } from '../types';

interface DashboardViewProps {
  kpi: KpiSummary | null;
  charts: ChartDataSets | null;
  recentAnomalies: AnomalyCase[];
  onSelectAnomaly: (meter_id: string, date: string) => void;
  onNavigateToAnomalies: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  kpi,
  charts,
  recentAnomalies,
  onSelectAnomaly,
  onNavigateToAnomalies,
}) => {
  return (
    <div className="space-y-6">
      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Meters</span>
            <Activity className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-3xl font-mono font-bold text-white">
            {kpi ? kpi.total_meters : '30'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Active channels monitored across 5 zones
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-sky-500/5 rounded-full blur-2xl pointer-events-none" />
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Records</span>
            <Database className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-3xl font-mono font-bold text-white">
            {kpi ? kpi.total_records.toLocaleString() : '10,950'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            365 days of load telemetry ingested
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Anomalies</span>
            <AlertOctagon className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-mono font-bold text-amber-400">
            {kpi ? kpi.total_anomalies : '—'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Flagged via Isolation Forest analytics
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
        </div>

        <div className="bg-slate-900 border-l-4 border-rose-500 border-y border-r border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">High Priority Cases</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-3xl font-mono font-bold text-rose-400">
            {kpi ? kpi.high_priority_cases : '—'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Acute deviations (&ge;50% or anomaly score &ge;0.70)
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-rose-500/5 rounded-full blur-2xl pointer-events-none" />
        </div>
      </div>

      {/* Primary Analytics Charts (Row 1: Trend & Anomalies Over Time) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Electricity Consumption Trend */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-sky-400" />
                1. Monthly Electricity Consumption Trend
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Mean daily load (kWh) aggregated across all 30 meters
              </p>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              2025 Trendline
            </span>
          </div>

          <div className="h-56 w-full flex items-end gap-2 pt-6 pb-2 px-2 border-b border-slate-800">
            {charts && charts.consumption_trend.length > 0 ? (
              charts.consumption_trend.map((pt, i) => {
                const maxVal = Math.max(...charts.consumption_trend.map((c) => c.average_kwh), 100);
                const heightPct = Math.max(12, Math.round((pt.average_kwh / maxVal) * 100));
                const monthName = pt.period.split('-')[1];
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1 group relative">
                    <div className="opacity-0 group-hover:opacity-100 absolute -top-8 bg-slate-950 text-white text-[10px] font-mono px-2 py-1 rounded border border-slate-700 pointer-events-none whitespace-nowrap z-10 transition">
                      {pt.period}: {pt.average_kwh} kWh
                    </div>
                    <div
                      style={{ height: `${heightPct}%` }}
                      className="w-full bg-gradient-to-t from-sky-600 to-sky-400 rounded-t-sm transition-all group-hover:from-sky-500 group-hover:to-sky-300"
                    />
                    <span className="text-[10px] text-slate-400 font-mono mt-1">{monthName}</span>
                  </div>
                );
              })
            ) : (
              <div className="text-xs text-slate-400 m-auto">Loading trend telemetry...</div>
            )}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 px-1">
            <span>Jan 2025</span>
            <span className="text-sky-400 font-mono">Summer Peak (May–Jun)</span>
            <span>Dec 2025</span>
          </div>
        </div>

        {/* Chart 2: Anomalies Over Time */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-purple-400" />
                2. Anomalies Detected Over Time
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Monthly distribution of flagged anomalies categorized by priority
              </p>
            </div>
            <div className="flex items-center gap-3 text-[10px]">
              <span className="flex items-center gap-1 text-rose-300">
                <span className="w-2 h-2 rounded-full bg-rose-500" /> High
              </span>
              <span className="flex items-center gap-1 text-amber-300">
                <span className="w-2 h-2 rounded-full bg-amber-500" /> Medium
              </span>
              <span className="flex items-center gap-1 text-sky-300">
                <span className="w-2 h-2 rounded-full bg-sky-500" /> Low
              </span>
            </div>
          </div>

          <div className="h-56 w-full flex items-end gap-2 pt-6 pb-2 px-2 border-b border-slate-800">
            {charts && charts.anomalies_over_time.length > 0 ? (
              charts.anomalies_over_time.map((pt, i) => {
                const maxTotal = Math.max(...charts.anomalies_over_time.map((c) => c.total), 10);
                const highPct = Math.round((pt.high / maxTotal) * 100);
                const medPct = Math.round((pt.medium / maxTotal) * 100);
                const lowPct = Math.round((pt.low / maxTotal) * 100);
                const monthName = pt.period.split('-')[1];

                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1 group relative">
                    <div className="opacity-0 group-hover:opacity-100 absolute -top-10 bg-slate-950 text-white text-[10px] font-mono px-2 py-1 rounded border border-slate-700 pointer-events-none whitespace-nowrap z-10 transition">
                      {pt.period}: {pt.total} anomalies (H:{pt.high}, M:{pt.medium}, L:{pt.low})
                    </div>
                    <div className="w-full flex flex-col justify-end h-full">
                      {pt.high > 0 && (
                        <div style={{ height: `${highPct}%` }} className="w-full bg-rose-500 rounded-t-sm" />
                      )}
                      {pt.medium > 0 && (
                        <div style={{ height: `${medPct}%` }} className="w-full bg-amber-500" />
                      )}
                      {pt.low > 0 && (
                        <div style={{ height: `${lowPct}%` }} className="w-full bg-sky-500 rounded-b-sm" />
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono mt-1">{monthName}</span>
                  </div>
                );
              })
            ) : (
              <div className="text-xs text-slate-400 m-auto">Loading anomaly counts...</div>
            )}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 px-1">
            <span>Incident Timeline</span>
            <span className="text-purple-400 font-mono">Cluster Injections Flagged</span>
            <span>12 Months</span>
          </div>
        </div>
      </div>

      {/* Secondary Analytics Charts (Row 2: Consumer Type, Location, Priority) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Chart 3: Consumption by Consumer Type */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col">
          <div className="mb-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              3. Total Energy by Consumer Type
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Aggregated annual energy consumption (MWh)
            </p>
          </div>

          <div className="space-y-3 my-auto">
            {charts?.consumption_by_type.map((item, i) => {
              const maxKwh = Math.max(...charts.consumption_by_type.map((c) => c.total_kwh));
              const pct = Math.round((item.total_kwh / maxKwh) * 100);
              const mwh = Math.round(item.total_kwh / 1000);

              const colorMap: Record<string, string> = {
                Residential: 'bg-sky-500',
                Commercial: 'bg-amber-500',
                Industrial: 'bg-purple-500',
                Institutional: 'bg-emerald-500',
              };

              return (
                <div key={i} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-medium">{item.type}</span>
                    <span className="font-mono text-slate-400">{mwh.toLocaleString()} MWh</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      style={{ width: `${pct}%` }}
                      className={`h-full ${colorMap[item.type] || 'bg-sky-500'} rounded-full`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 4: Anomalies by Location */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col">
          <div className="mb-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-cyan-400" />
              4. Anomalies by Location
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Regional anomaly distribution across Chennai utility sectors
            </p>
          </div>

          <div className="space-y-3 my-auto">
            {charts?.anomalies_by_location.map((loc, i) => {
              const maxAnom = Math.max(...charts.anomalies_by_location.map((l) => l.total_anomalies));
              const pct = Math.round((loc.total_anomalies / maxAnom) * 100);

              return (
                <div key={i} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-medium">{loc.location}</span>
                    <span className="font-mono text-slate-400">
                      {loc.total_anomalies} cases ({loc.high_priority} High)
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div style={{ width: `${pct}%` }} className="h-full bg-cyan-500 rounded-full" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 5: Investigation Priority Distribution */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col">
          <div className="mb-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <PieChart className="w-4 h-4 text-rose-400" />
              5. Priority Distribution
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Decision-support triage breakdown for field inspection
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2.5 my-auto">
            {charts?.priority_distribution.map((p, i) => {
              const badgeColors: Record<string, { bg: string; text: string; border: string }> = {
                HIGH: { bg: 'bg-rose-500/10', text: 'text-rose-400', border: 'border-rose-500/25' },
                MEDIUM: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/25' },
                LOW: { bg: 'bg-sky-500/10', text: 'text-sky-400', border: 'border-sky-500/25' },
              };
              const c = badgeColors[p.priority] || badgeColors.LOW;

              return (
                <div
                  key={i}
                  className={`p-3 rounded-lg border text-center ${c.bg} ${c.border}`}
                >
                  <div className={`text-2xl font-mono font-bold ${c.text}`}>{p.count}</div>
                  <div className="text-[11px] font-bold mt-1 text-slate-300">{p.priority}</div>
                  <div className="text-[9px] text-slate-400 uppercase mt-0.5">Severity</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Priority Anomaly Cases Queue */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-base font-bold text-white">Priority Anomaly Cases for Field Verification</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Top prioritized cases identified by the Isolation Forest statistical pipeline
            </p>
          </div>
          <button
            onClick={onNavigateToAnomalies}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-sky-400 hover:text-sky-300"
          >
            <span>View All Anomalies</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <th className="p-3">Meter ID</th>
                <th className="p-3">Date</th>
                <th className="p-3">Type</th>
                <th className="p-3">Location</th>
                <th className="p-3">Consumption</th>
                <th className="p-3">Historical Avg</th>
                <th className="p-3">Deviation</th>
                <th className="p-3">Anomaly Score</th>
                <th className="p-3">Priority</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {recentAnomalies.slice(0, 8).map((a, i) => (
                <tr key={i} className="hover:bg-slate-800/30 transition">
                  <td className="p-3 font-mono font-bold text-slate-200">{a.meter_id}</td>
                  <td className="p-3 font-mono text-slate-400">{a.date}</td>
                  <td className="p-3 text-slate-300">{a.consumer_type}</td>
                  <td className="p-3 text-slate-400">{a.location}</td>
                  <td className="p-3 font-mono font-bold text-white">{a.consumption.toFixed(2)} kWh</td>
                  <td className="p-3 font-mono text-slate-400">{a.historical_average.toFixed(2)} kWh</td>
                  <td className="p-3 font-mono">
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        a.percentage_change < 0
                          ? 'bg-rose-500/15 text-rose-300'
                          : 'bg-amber-500/15 text-amber-300'
                      }`}
                    >
                      {a.percentage_change > 0 ? '+' : ''}
                      {a.percentage_change.toFixed(1)}%
                    </span>
                  </td>
                  <td className="p-3 font-mono text-purple-400">{a.anomaly_score.toFixed(4)}</td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        a.priority === 'HIGH'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : a.priority === 'MEDIUM'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                      }`}
                    >
                      {a.priority}
                    </span>
                  </td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => onSelectAnomaly(a.meter_id, a.date)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-sky-500/10 hover:bg-sky-500 text-sky-400 hover:text-slate-900 border border-sky-500/30 font-medium transition text-xs"
                    >
                      Investigate &rarr;
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
