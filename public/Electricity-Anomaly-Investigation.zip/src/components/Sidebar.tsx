import React from 'react';
import { 
  LayoutDashboard, 
  AlertTriangle, 
  Gauge, 
  SearchCode, 
  Info, 
  Zap,
  Database,
  ShieldCheck
} from 'lucide-react';
import { ActiveTab } from '../types';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  anomaliesCount: number;
  highPriorityCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  anomaliesCount,
  highPriorityCount,
}) => {
  const navItems: Array<{ id: ActiveTab; label: string; icon: React.ReactNode; badge?: string | number }> = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-4 h-4" />,
    },
    {
      id: 'anomalies',
      label: 'Anomaly Cases',
      icon: <AlertTriangle className="w-4 h-4" />,
      badge: anomaliesCount > 0 ? anomaliesCount : undefined,
    },
    {
      id: 'meters',
      label: 'Meter Analysis',
      icon: <Gauge className="w-4 h-4" />,
    },
    {
      id: 'investigation',
      label: 'AI Investigation',
      icon: <SearchCode className="w-4 h-4" />,
      badge: highPriorityCount > 0 ? `${highPriorityCount} High` : undefined,
    },
    {
      id: 'about',
      label: 'About Project',
      icon: <Info className="w-4 h-4" />,
    },
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0 min-h-screen">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-sky-600 to-sky-400 flex items-center justify-center text-white shadow-md shadow-sky-500/20">
            <Zap className="w-5 h-5 fill-current" />
          </div>
          <div>
            <div className="text-sm font-bold tracking-tight text-white leading-tight">
              GridAnomaly AI
            </div>
            <div className="text-[11px] text-sky-400 font-mono tracking-wide">
              Agentic Utility Platform
            </div>
          </div>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="p-3 space-y-1.5 flex-1">
        <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Main Navigation
        </div>
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-medium transition ${
                isActive
                  ? 'bg-sky-600 text-white shadow-sm shadow-sky-500/20 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-3">
                {item.icon}
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                    isActive
                      ? 'bg-sky-800/80 text-sky-100'
                      : typeof item.badge === 'string' && item.badge.includes('High')
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Dataset & Architecture Footnote */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/60 space-y-3">
        <a
          href="/api/download-zip"
          download="Electricity-Anomaly-Investigation.zip"
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-sm transition"
        >
          <Zap className="w-3.5 h-3.5" />
          <span>Download Project (.zip)</span>
        </a>

        <div className="rounded-lg bg-slate-900 border border-slate-800 p-3 space-y-2">
          <div className="flex items-center gap-2 text-[11px] font-semibold text-slate-300">
            <Database className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span className="truncate">Uploaded CSV Dataset</span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono break-all leading-tight">
            electricity_consumption_demo_under_20mb.csv
          </div>
          <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-[10px] text-slate-400">
            <span>30 Meters</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> Live Feed
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
};
