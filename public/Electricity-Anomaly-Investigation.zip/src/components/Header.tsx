import React from 'react';
import { ShieldAlert, Cpu, Sparkles, Download } from 'lucide-react';

interface HeaderProps {
  geminiActive?: boolean;
}

export const Header: React.FC<HeaderProps> = ({ geminiActive }) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 shrink-0">
      <div className="px-6 py-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-lg md:text-xl font-bold tracking-tight text-white flex items-center gap-2">
            AI-Driven Electricity Consumption Anomaly Detection and Investigation
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Big Data + Anomaly Detection + Agentic AI Decision Support
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-sky-500/10 text-sky-400 border border-sky-500/20">
            <Cpu className="w-3.5 h-3.5" />
            <span>Isolation Forest Analytics</span>
          </div>
          <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border ${
            geminiActive 
              ? 'bg-purple-500/10 text-purple-300 border-purple-500/25' 
              : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/25'
          }`}>
            <Sparkles className="w-3.5 h-3.5" />
            <span>{geminiActive ? 'Gemini 3.8 Flash Active' : 'Deterministic AI Reasoning'}</span>
          </div>
          <a
            href="/api/download-zip"
            download="Electricity-Anomaly-Investigation.zip"
            className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-sky-600 hover:bg-sky-500 text-white shadow-sm transition"
            title="Download full project zip archive"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Project (.zip)</span>
          </a>
        </div>
      </div>

      {/* Critical System Limitation Banner */}
      <div className="bg-amber-500/10 border-t border-b border-amber-500/20 px-6 py-2.5 text-xs text-amber-200">
        <div className="flex items-center gap-2.5">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
          <div className="leading-snug">
            <strong className="text-amber-300 font-semibold">Critical Protocol Notice:</strong>{' '}
            The platform detects anomalous consumption patterns and flags potentially suspicious consumption patterns requiring investigation.{' '}
            <span className="font-semibold underline decoration-amber-400/50">
              An anomaly does not prove electricity theft.
            </span>{' '}
            Human and technical verification are required before initiating administrative, commercial, or regulatory action.
          </div>
        </div>
      </div>
    </header>
  );
};
