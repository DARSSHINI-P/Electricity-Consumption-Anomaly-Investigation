import React from 'react';
import { 
  BookOpen, 
  Layers, 
  Lightbulb, 
  ShieldAlert, 
  Server, 
  Cpu, 
  GitBranch, 
  Workflow, 
  FileCheck2,
  HardDrive,
  Zap
} from 'lucide-react';

export const AboutProjectView: React.FC = () => {
  return (
    <div className="space-y-6 max-w-5xl">
      {/* Title Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-sky-400 bg-sky-500/10 px-2.5 py-1 rounded border border-sky-500/20">
          Academic Research Framework
        </span>
        <h2 className="text-xl font-bold text-white mt-3">
          AI-Driven Electricity Consumption Anomaly Detection and Investigation using Big Data and Agentic AI
        </h2>
        <p className="text-xs text-slate-300 mt-2 leading-relaxed">
          An intelligent decision-support architecture for electric power distribution utilities, bridging 
          statistical time-series outlier detection with autonomous multi-step forensic reasoning.
        </p>
      </div>

      {/* Problem, Solution, Contribution, Limitation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Problem */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-2.5">
          <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
            <ShieldAlert className="w-4 h-4" />
            <h3>THE PROBLEM</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Electricity distribution utilities monitor hundreds of thousands of smart meters generating high-frequency interval readings.
            Manual inspection of vast telemetry datasets is infeasible, while traditional static rule thresholds produce massive false-positive 
            rates due to seasonal weather changes, holidays, and varied consumer types.
          </p>
        </div>

        {/* Proposed Solution */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-2.5">
          <div className="flex items-center gap-2 text-sky-400 font-bold text-sm">
            <Lightbulb className="w-4 h-4" />
            <h3>PROPOSED SOLUTION</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The system combines unsupervised multi-dimensional consumption anomaly detection (Isolation Forest style) with an Agentic AI 
            investigation layer. When an outlier is flagged, the agent autonomously retrieves historical baselines, quantifies statistical deviations, 
            formulates plausible engineering explanations, and generates structured verification dossiers.
          </p>
        </div>

        {/* Key Contribution */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-2.5">
          <div className="flex items-center gap-2 text-purple-400 font-bold text-sm">
            <Workflow className="w-4 h-4" />
            <h3>KEY CONTRIBUTION</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The defining innovation is the <strong>integration of anomaly detection with an Agentic AI investigation layer</strong>. 
            Instead of stopping after flagging an anomaly score, the system autonomously conducts forensic reasoning to explain 
            <em>why</em> the anomaly occurred and provides utility engineers with actionable, prioritized verification protocols.
          </p>
        </div>

        {/* System Limitation */}
        <div className="bg-slate-900 border border-amber-500/30 rounded-xl p-6 shadow-xl space-y-2.5 bg-amber-500/[0.03]">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
            <FileCheck2 className="w-4 h-4" />
            <h3>SYSTEM LIMITATION & ETHICS</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The system is strictly an academic decision-support prototype. 
            <strong> An anomaly does not prove electricity theft.</strong> 
            Benign causes—such as seasonal plant shutdowns, consumer vacations, solar PV additions, feeder maintenance, or meter CT failures—frequently 
            resemble loss patterns. Physical on-site inspection and technical testing are mandatory.
          </p>
        </div>
      </div>

      {/* Big Data Scalable Architecture */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-5">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Server className="w-4 h-4 text-sky-400" />
            Scalable Big Data Production Architecture
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Proposed enterprise distributed architecture for utility-scale smart grid deployments (Millions of AMI meters):
          </p>
        </div>

        {/* Visual Pipeline Flow */}
        <div className="bg-slate-950 p-5 rounded-lg border border-slate-800 text-xs font-mono text-slate-300 space-y-2 overflow-x-auto">
          <div className="flex flex-wrap items-center gap-2 text-sky-300">
            <span className="px-3 py-1.5 rounded bg-slate-900 border border-slate-700">Large-Scale Electricity Data</span>
            <span>&rarr;</span>
            <span className="px-3 py-1.5 rounded bg-slate-900 border border-slate-700">HDFS / Distributed Lakehouse</span>
            <span>&rarr;</span>
            <span className="px-3 py-1.5 rounded bg-slate-900 border border-slate-700">PySpark Distributed Processing</span>
            <span>&rarr;</span>
            <span className="px-3 py-1.5 rounded bg-slate-900 border border-slate-700">Feature Engineering</span>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-purple-300 pt-2">
            <span className="px-3 py-1.5 rounded bg-slate-900 border border-slate-700">&rarr; Isolation Forest Models</span>
            <span>&rarr;</span>
            <span className="px-3 py-1.5 rounded bg-slate-900 border border-slate-700">Agentic AI Investigation Layer</span>
            <span>&rarr;</span>
            <span className="px-3 py-1.5 rounded bg-slate-900 border border-slate-700">Utility Decision Dashboard</span>
            <span>&rarr;</span>
            <span className="px-3 py-1.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-500/30">Human / Field Verification</span>
          </div>
        </div>

        <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800/80 text-xs text-slate-400 leading-relaxed">
          <strong className="text-slate-200">Demonstration Note:</strong> The current prototype processes the uploaded{' '}
          <code className="text-sky-300 font-mono">electricity_consumption_demo_under_20mb.csv</code> dataset locally within the full-stack 
          environment (30 meters &bull; 365 days &bull; 10,950 records across Chennai zones) to demonstrate the complete end-to-end analytical pipeline 
          in real time without requiring external cluster infrastructure.
        </div>
      </div>

      {/* Project Source Code Package & Download Card */}
      <div className="bg-gradient-to-r from-sky-950/50 via-slate-900 to-slate-900 border border-sky-500/30 rounded-xl p-6 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20">
                Offline Distribution Package
              </span>
            </div>
            <h3 className="text-base font-bold text-white mt-1 flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-sky-400" />
              Download Complete Project Archive (.zip)
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Contains the complete Python, Flask, React, and Node.js codebase, dataset, detector, agent, and templates.
            </p>
          </div>

          <a
            href="/api/download-zip"
            download="Electricity-Anomaly-Investigation.zip"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow-lg shadow-sky-600/30 transition transform hover:-translate-y-0.5"
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>Download Project ZIP (1.5 MB)</span>
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-[11px] font-mono text-slate-300">
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
            <div className="font-bold text-sky-400">Python / Flask Execution:</div>
            <div className="text-slate-400">pip install -r requirements.txt</div>
            <div className="text-slate-400">python run.py --process</div>
            <div className="text-slate-400">python run.py (runs at http://127.0.0.1:5000)</div>
          </div>
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
            <div className="font-bold text-sky-400">Full-Stack Node.js Execution:</div>
            <div className="text-slate-400">npm install</div>
            <div className="text-slate-400">npm run dev (runs at http://localhost:3000)</div>
            <div className="text-slate-400">GEMINI_API_KEY optional for AI briefings</div>
          </div>
        </div>
      </div>
    </div>
  );
};
