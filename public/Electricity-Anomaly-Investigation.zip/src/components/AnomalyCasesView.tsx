import React, { useState, useMemo } from 'react';
import { Search, Filter, RotateCcw, AlertCircle, ArrowUpDown } from 'lucide-react';
import { AnomalyCase } from '../types';

interface AnomalyCasesViewProps {
  anomalies: AnomalyCase[];
  onInvestigate: (meter_id: string, date: string) => void;
}

export const AnomalyCasesView: React.FC<AnomalyCasesViewProps> = ({
  anomalies,
  onInvestigate,
}) => {
  const [search, setSearch] = useState('');
  const [meterFilter, setMeterFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [locationFilter, setLocationFilter] = useState('ALL');
  const [priorityFilter, setPriorityFilter] = useState('ALL');
  const [dateFilter, setDateFilter] = useState('');
  const [sortField, setSortField] = useState<'date' | 'consumption' | 'percentage_change' | 'anomaly_score' | 'priority'>('anomaly_score');
  const [sortAsc, setSortAsc] = useState(false);

  // Extract unique meters and options
  const uniqueMeters = useMemo(() => {
    return Array.from(new Set(anomalies.map((a) => a.meter_id))).sort();
  }, [anomalies]);

  const uniqueLocations = useMemo(() => {
    return Array.from(new Set(anomalies.map((a) => a.location))).sort();
  }, [anomalies]);

  // Filter & sort
  const filteredCases = useMemo(() => {
    return anomalies
      .filter((a) => {
        if (meterFilter !== 'ALL' && a.meter_id !== meterFilter) return false;
        if (typeFilter !== 'ALL' && a.consumer_type !== typeFilter) return false;
        if (locationFilter !== 'ALL' && a.location !== locationFilter) return false;
        if (priorityFilter !== 'ALL' && a.priority !== priorityFilter) return false;
        if (dateFilter && !a.date.includes(dateFilter)) return false;

        if (search.trim()) {
          const q = search.toLowerCase().trim();
          const match =
            a.meter_id.toLowerCase().includes(q) ||
            a.date.includes(q) ||
            a.location.toLowerCase().includes(q) ||
            a.consumer_type.toLowerCase().includes(q);
          if (!match) return false;
        }

        return true;
      })
      .sort((a, b) => {
        let cmp = 0;
        if (sortField === 'date') cmp = a.date.localeCompare(b.date);
        else if (sortField === 'consumption') cmp = a.consumption - b.consumption;
        else if (sortField === 'percentage_change') cmp = Math.abs(a.percentage_change) - Math.abs(b.percentage_change);
        else if (sortField === 'anomaly_score') cmp = a.anomaly_score - b.anomaly_score;
        else if (sortField === 'priority') {
          const rank: Record<string, number> = { HIGH: 3, MEDIUM: 2, LOW: 1 };
          cmp = (rank[a.priority] || 0) - (rank[b.priority] || 0);
        }
        return sortAsc ? cmp : -cmp;
      });
  }, [anomalies, meterFilter, typeFilter, locationFilter, priorityFilter, dateFilter, search, sortField, sortAsc]);

  const handleResetFilters = () => {
    setSearch('');
    setMeterFilter('ALL');
    setTypeFilter('ALL');
    setLocationFilter('ALL');
    setPriorityFilter('ALL');
    setDateFilter('');
  };

  const handleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Filters Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Filter className="w-4 h-4 text-sky-400" />
              Anomaly Cases Triage Filter
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Filter detected consumption anomalies across distribution sectors
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium text-slate-300">
              Showing <strong className="text-sky-400">{filteredCases.length}</strong> of {anomalies.length} cases
            </span>
            <button
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Filters
            </button>
          </div>
        </div>

        {/* Filters Matrix */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Search */}
          <div className="col-span-2 sm:col-span-1">
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Search</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Meter, zone..."
                className="w-full bg-slate-950 text-white text-xs pl-8 pr-2.5 py-1.5 rounded-lg border border-slate-800 outline-none focus:border-sky-500"
              />
            </div>
          </div>

          {/* Meter ID */}
          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Meter</label>
            <select
              value={meterFilter}
              onChange={(e) => setMeterFilter(e.target.value)}
              className="w-full bg-slate-950 text-white text-xs px-2.5 py-1.5 rounded-lg border border-slate-800 outline-none focus:border-sky-500"
            >
              <option value="ALL">All Meters</option>
              {uniqueMeters.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          {/* Consumer Type */}
          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Type</label>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full bg-slate-950 text-white text-xs px-2.5 py-1.5 rounded-lg border border-slate-800 outline-none focus:border-sky-500"
            >
              <option value="ALL">All Consumer Types</option>
              <option value="Residential">Residential</option>
              <option value="Commercial">Commercial</option>
              <option value="Industrial">Industrial</option>
              <option value="Institutional">Institutional</option>
            </select>
          </div>

          {/* Location */}
          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Location</label>
            <select
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
              className="w-full bg-slate-950 text-white text-xs px-2.5 py-1.5 rounded-lg border border-slate-800 outline-none focus:border-sky-500"
            >
              <option value="ALL">All Locations</option>
              {uniqueLocations.map((loc) => (
                <option key={loc} value={loc}>{loc}</option>
              ))}
            </select>
          </div>

          {/* Priority */}
          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Priority</label>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="w-full bg-slate-950 text-white text-xs px-2.5 py-1.5 rounded-lg border border-slate-800 outline-none focus:border-sky-500"
            >
              <option value="ALL">All Priorities</option>
              <option value="HIGH">High Priority Only</option>
              <option value="MEDIUM">Medium Priority Only</option>
              <option value="LOW">Low Priority Only</option>
            </select>
          </div>

          {/* Date */}
          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Date Substring</label>
            <input
              type="text"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              placeholder="e.g. 2025-04"
              className="w-full bg-slate-950 text-white text-xs px-2.5 py-1.5 rounded-lg border border-slate-800 outline-none focus:border-sky-500"
            />
          </div>
        </div>
      </div>

      {/* Anomaly Cases Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <th className="p-3 font-semibold">Meter ID</th>
                <th className="p-3 font-semibold cursor-pointer select-none" onClick={() => handleSort('date')}>
                  <div className="flex items-center gap-1">Date <ArrowUpDown className="w-3 h-3" /></div>
                </th>
                <th className="p-3 font-semibold">Consumer Type</th>
                <th className="p-3 font-semibold">Location</th>
                <th className="p-3 font-semibold cursor-pointer select-none" onClick={() => handleSort('consumption')}>
                  <div className="flex items-center gap-1">Consumption <ArrowUpDown className="w-3 h-3" /></div>
                </th>
                <th className="p-3 font-semibold">Historical Avg</th>
                <th className="p-3 font-semibold cursor-pointer select-none" onClick={() => handleSort('percentage_change')}>
                  <div className="flex items-center gap-1">Deviation (%) <ArrowUpDown className="w-3 h-3" /></div>
                </th>
                <th className="p-3 font-semibold cursor-pointer select-none" onClick={() => handleSort('anomaly_score')}>
                  <div className="flex items-center gap-1">Anomaly Score <ArrowUpDown className="w-3 h-3" /></div>
                </th>
                <th className="p-3 font-semibold cursor-pointer select-none" onClick={() => handleSort('priority')}>
                  <div className="flex items-center gap-1">Priority <ArrowUpDown className="w-3 h-3" /></div>
                </th>
                <th className="p-3 text-right font-semibold">Investigation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredCases.length > 0 ? (
                filteredCases.map((a, i) => (
                  <tr key={i} className="hover:bg-slate-800/40 transition">
                    <td className="p-3 font-mono font-bold text-slate-200">{a.meter_id}</td>
                    <td className="p-3 font-mono text-slate-400">{a.date}</td>
                    <td className="p-3 text-slate-300">{a.consumer_type}</td>
                    <td className="p-3 text-slate-400">{a.location}</td>
                    <td className="p-3 font-mono font-bold text-white">{a.consumption.toFixed(2)} kWh</td>
                    <td className="p-3 font-mono text-slate-400">{a.historical_average.toFixed(2)} kWh</td>
                    <td className="p-3 font-mono">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          a.percentage_change < 0
                            ? 'bg-rose-500/15 text-rose-300'
                            : 'bg-amber-500/15 text-amber-300'
                        }`}
                      >
                        {a.percentage_change > 0 ? '+' : ''}
                        {a.percentage_change.toFixed(1)}%
                      </span>
                    </td>
                    <td className="p-3 font-mono text-purple-400">{a.anomaly_score.toFixed(4)}</td>
                    <td className="p-3">
                      <span
                        className={`px-2.5 py-0.5 rounded text-[10px] font-bold font-mono ${
                          a.priority === 'HIGH'
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : a.priority === 'MEDIUM'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        }`}
                      >
                        {a.priority}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => onInvestigate(a.meter_id, a.date)}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-sky-500/15 hover:bg-sky-500 text-sky-400 hover:text-slate-900 border border-sky-500/30 font-medium transition text-xs shadow-sm"
                      >
                        Investigate &rarr;
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <AlertCircle className="w-6 h-6 text-slate-500" />
                      <span>No anomaly cases match the selected filter criteria.</span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
